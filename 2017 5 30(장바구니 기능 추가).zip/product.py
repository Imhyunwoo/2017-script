class Product:
    def __init__(self, t, minp, maxp, l, m, b, i, cg, r, s):
        self.proDic = {"title":t,
                       "category":cg,
                       "최소가":minp,
                       "최고가":maxp,
                       "메이커":m,
                       "브랜드":b,
                       "쇼핑몰":s}
        self.link = l
        self.image = i
        self.review = r

    def printPro(self):
        s = ""
        for k, v in self.proDic.items():
            if v.text != None:
                if k not in  ("title", "category"):
                    s = s + k + " : "
                s = s + v.text + "\n"
                if k in ("title", "category"):
                    s = s + "\n"
        return s

    def get_title(self):
        return self.proDic["title"]

    def get_imageURL(self):
        return self.image.text

    def get_link(self):
        return self.link

    def get_review(self):
        return self.review
