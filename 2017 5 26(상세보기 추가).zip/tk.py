from tkinter import*
from tkinter import font
from http.client import HTTPConnection
from urllib.parse import quote
from product import Product

conn = None

regKey = '03797b74ab1a5059e8894c9af8f90cb8'

server = "apis.daum.net"

product = []

def searchURLBuilder(server, **user):
    str = "http://" + server + "/shopping/search" + "?"
    for key in user.keys():
        str += key + "=" + user[key] + "&"
    return str

def connectOpenAPIServer():
    global conn, server
    conn = HTTPConnection(server)

def getshoppingData(name):
    global server, regKey, conn, product
    if conn == None :
        connectOpenAPIServer()
    searchLB.delete(0, END)
    product.clear()
    for i in range(3):
        uri = searchURLBuilder(server, apikey=regKey, q=quote(name), result = '20', sort = 'pop', pageno=str(i+1))
        conn.request("GET", uri)
        req = conn.getresponse()
        if int(req.status) == 200:
            print("Book data downloading complete!")
            insertData(req.read())
        else:
            print("OpenAPI request has been failed!! please retry")
            return None
    i = 1
    print(len(product))
    for p in product:
        searchLB.insert(i, p.get_title().text)
        i += 1

def insertData(strXml):
    global product
    from xml.etree import ElementTree
    tree = ElementTree.fromstring(strXml)
    itemElements = tree.getiterator("item")
    insertSearchLB(itemElements)

window = Tk()
window.configure(width = 800, height = 600)

def click_searchB():
    key = str(searchE.get())
    getshoppingData(key)

def insertSearchLB(data):
    global product
    for item in data:
        link = item.find("link")
        review = item.find("review_count")
        shoppingmall = item.find("shoppingmall")
        category = item.find("category_name")
        image = item.find("image_url")
        brand = item.find("brand")
        maker = item.find("maker")
        price_max = item.find("price_max")
        price_min = item.find("price_min")
        title = item.find("title")
        product.append(Product(title, price_min, price_max,
                               link, maker, brand, image,
                               category, review, shoppingmall))

def openDetail():
    detail = Toplevel(window, padx=20, pady=20)
    detail.title("상세정보")

    t = Label(detail, text="show me the money")
    t.pack()
    b = Button(detail, text="구매하러가기")
    b.pack()

# Logo Create
logofont = font.Font(window, family='Coutier',
                     size=30,
                     weight='bold',
                     slant='italic')
logo = Label(window,
                  font=logofont,
                  text="SHOPPING",
                  fg='red')
logo.place(x=10, y=10)

# Search_Button Create
searchB = Button(window,
                 text="검색",
                 width=10,
                 command = click_searchB)
searchB.place(x=300, y=80)

# Search_Entry Create
searchE = Entry(window,
                bd=3,
                width=35)
searchE.place(x=30, y=80)

# Search_ListBox Create
LBscrollbar1 = Scrollbar(window)
searchLB = Listbox(window,
                   bd=8,
                   width=50,
                   height=25,
                   yscrollcommand=LBscrollbar1.set)
LBscrollbar1.place(x=390, y=160, height=420)
searchLB.place(x=20, y=160)
LBscrollbar1.config(command=searchLB.yview)

# Check_List Create
CheckVar = IntVar()
check1 = Radiobutton(window,
                     text="인기순",
                     value = 0,
                     variable=CheckVar)
check2 = Radiobutton(window,
                     text="최고가순",
                     value = 1,
                     variable=CheckVar)
check3 = Radiobutton(window,
                     text="최저가순",
                     value = 2,
                     variable=CheckVar)
check4 = Radiobutton(window,
                     text="리뷰순",
                     value = 3,
                     variable=CheckVar)
check1.place(x=30, y=130)
check2.place(x=110, y=130)
check3.place(x=200, y=130)
check4.place(x=290, y=130)

def test():
    defont = font.Font(window,
                       family = 'Coutier',
                       weight = 'bold')
    s = searchLB.curselection()[0]
    t = searchLB.get(s)
    print(searchLB.curselection()," : ", t)
    print(product[0].get_title().text)
    var = StringVar()
    detailM = Message(window,
                      font = defont,
                      textvariable=var,
                      relief=SOLID,
                      anchor='nw',
                      width=350)
    var.set(product[s].printPro())
    detailM.place(x=420, y=160, width=360, height=320)
    print("3")

# Goto_Detail_Button Create
detailB = Button(window,
                 text="상세보기",
                 width=50,
                 height=4,
                 command=test)
detailB.place(x=420, y=500)


window.mainloop()
