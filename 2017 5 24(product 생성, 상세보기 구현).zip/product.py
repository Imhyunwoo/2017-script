class Product:
    def __init__(self, t, minp, maxp, l, m, b, i, cg, r, s):
        self.title = t
        self.min_place = minp
        self.max_place = maxp
        self.link = l
        self.maker = m
        self.brand = b
        self.image = i
        self.category = cg
        self.review = r
        self.shoppingmall = s

    def get_title(self):
        return self.title

    def get_min_place(self):
        return self.min_place

    def get_max_place(self):
        return self.max_place

    def get_link(self):
        return self.link

    def get_maker(self):
        return self.maker

    def get_image(self):
        return self.image

    def get_category(self):
        return self.category

    def get_review(self):
        return self.review

    def get_brand(self):
        return self.brand
