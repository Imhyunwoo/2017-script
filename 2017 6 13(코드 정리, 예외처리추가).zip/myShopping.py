from tkinter import*
from tkinter import font
from urllib.parse import quote
from product import Product
import webbrowser
import urllib
import urllib.request
from PIL import Image, ImageTk
from io import BytesIO
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from http.client import HTTPConnection
import mysmtplib

### 전역변수 선언

conn = None
raw_data = None
im = None
photo = None
u = None

regKey = '03797b74ab1a5059e8894c9af8f90cb8'
server = "apis.daum.net"
host = "smtp.gmail.com"
port = "587"
senderAddr = None
password = None
recipientAddr = None
msg = MIMEBase("multipart", "alternative")

product = []
suf_product = []
basketlist = []

mailproduct = None

window = Tk()
window.configure(width = 800, height = 600)


### 함수 선언

def searchURLBuilder(server, **user):  # 검색할 URL만들기
    str = "http://" + server + "/shopping/search" + "?"
    for key in user.keys():
        str += key + "=" + user[key] + "&"
    return str

def connectOpenAPIServer():  # connect 생성
    global conn, server
    conn = HTTPConnection(server)

def getshoppingData(name):  # 검색하기
    global server, regKey, conn, product
    if conn == None :
        connectOpenAPIServer()
    searchLB.delete(0, END)
    product.clear()
    for i in range(3):
        uri = searchURLBuilder(server, apikey=regKey, q=quote(name), result = '20', sort = 'pop', pageno=str(i+1))
        conn.request("GET", uri)
        req = conn.getresponse()
        if int(req.status) == 200:
            print("Book data downloading complete!")
            insertData(req.read())
        else:
            print("OpenAPI request has been failed!! please retry")
            return None
        conn.close()
    i = 0
    print(len(product))
    for p in product:
        searchLB.insert(i, p.get_title().text)
        i += 1

def insertData(strXml):  # 데이터 트리 만들기
    global product
    from xml.etree import ElementTree
    tree = ElementTree.fromstring(strXml)
    itemElements = tree.getiterator("item")
    insertSearchLB(itemElements)

def click_searchB():  # 검색 버튼 클릭
    key = str(searchE.get())
    getshoppingData(key)
    basketB.config(text="장바구니담기",
                   command=inputbasket)
    var.set("")

def insertSearchLB(data):  # listbox에 데이터 넣기
    global product, suf_product
    for item in data:
        link = item.find("link")
        review = item.find("review_count")
        shoppingmall = item.find("shoppingmall")
        category = item.find("category_name")
        image = item.find("image_url")
        brand = item.find("brand")
        maker = item.find("maker")
        price_max = item.find("price_max")
        price_min = item.find("price_min")
        title = item.find("title")
        product.append(Product(title, price_min, price_max,
                               link, maker, brand, image,
                               category, review, shoppingmall))
        suf_product.append(Product(title, price_min, price_max,
                               link, maker, brand, image,
                               category, review, shoppingmall))

def sortR_key(n):  # review 정렬 key
    return eval(n.get_review().text)

def sortMinp_key(n):  # 최솟값 정렬 key
    return eval(n.get_minplace().text)

def sortMaxp_key(n):  # 최댓값 정렬 key
    return eval(n.get_maxplace().text)

def normalSort():  # 인기순 정렬로 바꾸기
    product.clear()
    for i in suf_product:
        product.append(i)
    searchLB.delete(0, END)
    num = 0
    for i in product:
        searchLB.insert(num, i.get_title().text)
        num += 1

def rebiewSort():  # 리뷰순 정렬로 바꾸기
    product.sort(reverse=False, key = sortR_key)
    searchLB.delete(0, END)
    num = 0
    for i in product:
        searchLB.insert(num, i.get_title().text)
        num += 1

def minPSort():  # 최솟값순 정렬로 바꾸기
    product.sort(reverse=False, key = sortMinp_key)
    searchLB.delete(0, END)
    num = 0
    for i in product:
        searchLB.insert(num, i.get_title().text)
        num += 1

def maxPSort():  # 최댓값순 정렬로 바꾸기
    product.sort(reverse=True, key = sortMaxp_key)
    searchLB.delete(0, END)
    num = 0
    for i in product:
        searchLB.insert(num, i.get_title().text)
        num += 1

def detailPro(evt):  # 상세보기
    w = evt.widget
    detail()

def detail():  # 상세보기
    global raw_data, im, photo, u
    try:
        s = searchLB.curselection()[0]
        t = searchLB.get(s)
        print(searchLB.curselection()," : ", t)
        print(product[0].get_title().text)

        with urllib.request.urlopen(product[s].get_imageURL()) as u:
            raw_data = u.read()
        im = Image.open(BytesIO(raw_data))
        photo = ImageTk.PhotoImage(im)
        imageL.config(image=photo)
        print(photo.width())

        var.set(product[s].printPro())

    except:
        var.set("목록에서 상품을 선택해 주십시오.")

def webopen():  # 쇼핑웹브라우저 열기
    try:
        s = searchLB.curselection()[0]
        webbrowser.open_new_tab(product[s].get_link().text)
    except:
        var.set("목록에서 상품을 선택해 주십시오.")

def inputbasket():  # 장바구니 담기
    try:
        s = searchLB.curselection()[0]
        if product[s] not in basketlist:
            basketlist.append(product[s])
        else:
            var.set("이미 담겨져 있습니다.")
        basketlistB.config(text="장바구니불러오기\n"
                          "< {0} >".format(len(basketlist)))
    except:
        var.set("목록에서 상품을 선택해 주십시오.")

def outputbasket():  # 장바구니 빼기
    try:
        s = searchLB.curselection()[0]
        product.pop(s)
        basketlist.pop(s)
        var.set("")
        searchLB.delete(0, END)
        num = 0
        for i in product:
            searchLB.insert(num, i.get_title().text)
            num += 1
        basketlistB.config(text="장바구니불러오기\n"
                          "< {0} >".format(len(basketlist)))
    except:
        var.set("목록에서 상품을 선택해 주십시오.")

def openbasketlist():  # 장바구니 열기
    global suf_product
    if len(basketlist) > 0:
        searchLB.delete(0, END)
        product.clear()
        suf_product.clear()
        for i in basketlist:
            product.append(i)
            suf_product.append(i)
        num = 0
        for i in product:
            searchLB.insert(num, i.get_title().text)
            num += 1
        basketB.config(text="장바구니빼기",
                       command=outputbasket)
    else:
        var.set("장바구니에 상품이 없습니다.")

def MakeHtmlDoc(ProductDic):   # html 만들기
    from xml.dom.minidom import getDOMImplementation
    # get Dom Implementation
    impl = getDOMImplementation()

    newdoc = impl.createDocument(None, "html", None)  # DOM 객체 생성
    top_element = newdoc.documentElement
    header = newdoc.createElement('header')
    top_element.appendChild(header)

    # Body 엘리먼트 생성.
    body = newdoc.createElement('body')

    for k, v in ProductDic.items():
        # create bold element
        b = newdoc.createElement('b')
        # create text node
        ibsnText = newdoc.createTextNode(k + " : " + v)
        b.appendChild(ibsnText)

        body.appendChild(b)

        # BR 태그 (엘리먼트) 생성.
        br = newdoc.createElement('br')

        body.appendChild(br)

    # append Body
    top_element.appendChild(body)

    return newdoc.toxml()

def sendmail():   # 메일보내기
    global loginIDE, loginPWE, recipientIDE, mailtext
    msg['Subject'] = "Shopping Data"
    msg['From'] = str(loginIDE.get())
    msg['To'] = str(recipientIDE.get())
    prodic = mailproduct.get_Dic()
    html = MakeHtmlDoc(prodic)
    print(mailtext.get(1.0, END))
    msgPart = MIMEText(str(mailtext.get(1.0, END)))
    proPart = MIMEText(html, 'html', _charset='UTF-8')

    # 메세지에 생성한 MIME 문서를 첨부합니다.
    msg.attach(proPart)
    msg.attach(msgPart)
    s = mysmtplib.MySMTP(host, port)
    # s.set_debuglevel(1)
    s.ehlo()
    s.starttls()
    s.ehlo()
    try:
        s.login(str(loginIDE.get()), str(loginPWE.get()))  # 로긴을 합니다.
    except:
        errorF = font.Font(window,
                           size=15,
                           weight='bold')
        errorT = Toplevel(window,
                          padx=20,
                          pady=20)
        errorL = Label(errorT,
                       font=errorF,
                       text="로그인 실패",
                       fg='red')
        errorL.pack()
        s.close()
        return
    s.sendmail(str(loginIDE.get()), [str(recipientIDE.get())], msg.as_string())
    s.close()

def mail():   # 메일보내기 toplevel
    global loginIDE, loginPWE, recipientIDE, mailtext, mailproduct
    try:
        p = searchLB.curselection()[0]
        mailproduct = product[p]

        mailtoplevel = Toplevel(window,
                                padx=20,
                                pady=20,
                                width=300,
                                height=300)
        mailtoplevel.title("메일보내기")

        loginIDL = Label(mailtoplevel,
                         text="보내는 ID")
        loginIDL.place(x=0, y=10)

        loginIDE = Entry(mailtoplevel,
                         width=25)
        loginIDE.place(x=80, y=10)

        loginPWL = Label(mailtoplevel,
                         text="PASSWORD")
        loginPWL.place(x=0, y=40)

        loginPWE = Entry(mailtoplevel,
                         width=25)
        loginPWE.place(x=80, y=40)

        recipientIDL = Label(mailtoplevel,
                             text="받는 ID")
        recipientIDL.place(x=0, y=70)

        recipientIDE = Entry(mailtoplevel,
                             width=25)
        recipientIDE.place(x=80, y=70)

        mailtextL = Label(mailtoplevel,
                          text="메시지")
        mailtextL.place(x=105, y=105)

        mailtext = Text(mailtoplevel,
                        width=37,
                        height=7)
        mailtext.place(x=0, y=130)

        sendmailB = Button(mailtoplevel,
                           text="메일 보내기",
                           command=sendmail)
        sendmailB.place(x=110, y=240)
    except:
        var.set("목록에서 상품을 선택해 주십시오.")

### 폰트
normalfont = font.Font(window,
                     size=10,
                     weight='bold')

logofont = font.Font(window, family='Coutier',
                     size=30,
                     weight='bold',
                     slant='italic')

defont = font.Font(window,
                   family='Coutier',
                   weight='bold',
                   size = 14)

### 로고
logo = Label(window,
                  font=logofont,
                  text="Shoppingmall",
                  fg='red')
logo.place(x=20, y=10)

### Search_Button Create
searchB = Button(window,
                 text="검 색",
                 font = normalfont,
                 width=11,
                 bd = 3,
                 command = click_searchB)
searchB.place(x=296, y=80)

### Search_Entry Create
searchE = Entry(window,
                bd=6,
                relief = RIDGE,
                font = normalfont,
                width=37)
searchE.place(x=30, y=80)

### search_listbox Create
LBscrollbar1 = Scrollbar(window)
searchLB = Listbox(window,
                   bd=8,
                   width=50,
                   height=25,
                   yscrollcommand=LBscrollbar1.set)
LBscrollbar1.place(x=390, y=160, height=420)
searchLB.place(x=20, y=160)
LBscrollbar1.config(command=searchLB.yview)
searchLB.bind('<<ListboxSelect>>', detailPro)

### sort_check
CheckVar = IntVar()
check1 = Radiobutton(window,
                     text="인기순",
                     value = 0,
                     variable=CheckVar,
                     command = normalSort)
check2 = Radiobutton(window,
                     text="최저가순",
                     value = 1,
                     variable=CheckVar,
                     command = minPSort)
check3 = Radiobutton(window,
                     text="최고가순",
                     value = 2,
                     variable=CheckVar,
                     command = maxPSort)
check4 = Radiobutton(window,
                     text="리뷰순",
                     value = 3,
                     variable=CheckVar,
                     command = rebiewSort)
check1.place(x=30, y=130)
check2.place(x=110, y=130)
check3.place(x=200, y=130)
check4.place(x=290, y=130)

### detail_message
var = StringVar()
detailM = Message(window,
                  font = defont,
                  textvariable=var,
                  relief=SOLID,
                  anchor='nw',
                  width=350)
detailM.place(x=420, y=160, width=360, height=420)

### detail_image
imageL = Label(window, relief = SOLID)
imageL.place(x=530, y=420, width = 140, height = 140)

### webbrowser_open
buyB = Button(window,
              font = normalfont,
              text="구입하러가기",
              width=20,
              height=2,
              bd = 4,
              command=webopen)
buyB.place(x=420, y=30)

### 장바구니_list_open
basketlistB = Button(window,
                     font = normalfont,
                     text="장바구니불러오기\n"
                          "< {0} >".format(len(basketlist)),
                     width = 20,
                     height=2,
                     bd = 4,
                     command=openbasketlist)
basketlistB.place(x=605, y=90)

### 장바구니_insert_button
basketB = Button(window,
                 font = normalfont,
                 text="장바구니담기",
                 width=20,
                 height=2,
                 bd = 4,
                 command=inputbasket)
basketB.place(x=420, y=90)

### email_button
mailB = Button(window,
               font = normalfont,
               text="메일보내기",
               width=20,
               height=2,
               bd = 4,
               command=mail)
mailB.place(x=605, y=30)


window.mainloop()