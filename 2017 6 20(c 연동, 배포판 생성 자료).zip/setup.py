from distutils.core import setup

setup(name='projectSSS',
      version='1.0',
      packages=['projectSSS']
      )
