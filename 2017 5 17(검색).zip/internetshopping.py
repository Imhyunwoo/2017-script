from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import quote

conn = None

regKey = '03797b74ab1a5059e8894c9af8f90cb8'

server = "apis.daum.net"

def searchURLBuilder(server, **user):
    str = "http://" + server + "/shopping/search" + "?"
    for key in user.keys():
        str += key + "=" + user[key] + "&"
    return str

def connectOpenAPIServer():
    global conn, server
    conn = HTTPConnection(server)

def getshoppingData(name):
    global server, regKey, conn
    if conn == None :
        connectOpenAPIServer()
    uri = searchURLBuilder(server, apikey=regKey, q=quote(name), result = '20', sort = 'pop')
    conn.request("GET", uri)
    req = conn.getresponse()
    if int(req.status) == 200:
        print("Book data downloading complete!")
        printshoppingData(req.read())
    else:
        print("OpenAPI request has been failed!! please retry")
        return None

def printshoppingData(strXml):
    from xml.etree import ElementTree
    tree = ElementTree.fromstring(strXml)
    itemElements = tree.getiterator("item")
    for item in itemElements:
        docid = item.find("docid")
        title = item.find("title")
        print(docid.text , "\t", title.text)