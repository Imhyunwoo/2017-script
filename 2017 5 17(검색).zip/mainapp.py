from internetshopping import*

running = 1

def printmenu():
    print("=====================")
    print("find : l")
    print("quit : q")
    print("=====================")

def selectmenu(menu):
    if menu == 'l':
        shopping()
    if menu == 'q':
        outapp()
    else:
        return

def shopping():
    s = input("what? : ")
    getshoppingData(s)

def outapp():
    global running
    running = 0

while(running):
    printmenu()
    menu = input("menu : ")
    selectmenu(menu)