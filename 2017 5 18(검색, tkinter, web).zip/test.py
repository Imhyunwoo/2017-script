import webbrowser

naver = "http://www.naver.com"

webbrowser.open_new_tab(naver)