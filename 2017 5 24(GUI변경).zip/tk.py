from tkinter import*
from tkinter import font
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import quote
import webbrowser

conn = None

regKey = '03797b74ab1a5059e8894c9af8f90cb8'

server = "apis.daum.net"

def searchURLBuilder(server, **user):
    str = "http://" + server + "/shopping/search" + "?"
    for key in user.keys():
        str += key + "=" + user[key] + "&"
    return str

def connectOpenAPIServer():
    global conn, server
    conn = HTTPConnection(server)

def getshoppingData(name):
    global server, regKey, conn
    if conn == None :
        connectOpenAPIServer()
    searchLB.delete(0, END)
    for i in range(3):
        uri = searchURLBuilder(server, apikey=regKey, q=quote(name), result = '20', sort = 'pop', pageno=str(i+1))
        conn.request("GET", uri)
        req = conn.getresponse()
        if int(req.status) == 200:
            print("Book data downloading complete!")
            insertData(req.read())
        else:
            print("OpenAPI request has been failed!! please retry")
            return None

def insertData(strXml):
    from xml.etree import ElementTree
    tree = ElementTree.fromstring(strXml)
    itemElements = tree.getiterator("item")
    insertSearchLB(itemElements)
    for item in itemElements:
        price = item.find("price_min")
        title = item.find("title")
        print(title.text , "\t", price.text)

window = Tk()
window.configure(width = 800, height = 600)

def click_searchB():
    key = str(searchE.get())
    getshoppingData(key)

def insertSearchLB(data):
    i = 1
    for item in data:
        title = item.find('title')
        searchLB.insert(i, title.text+"\t wow")
        i += 1

def openDetail():
    detail = Toplevel(window, padx=20, pady=20)
    detail.title("상세정보")

    t = Label(detail, text="show me the money")
    t.pack()
    b = Button(detail, text="구매하러가기")
    b.pack()

# Logo Create
logofont = font.Font(window, family='Coutier',
                     size=30,
                     weight='bold',
                     slant='italic')
logo = Label(window,
                  font=logofont,
                  text="SHOPPING",
                  fg='red')
logo.place(x=10, y=10)

# Search_Button Create
searchB = Button(window,
                 text="검색",
                 width=10,
                 command = click_searchB)
searchB.place(x=300, y=80)

# Search_Entry Create
searchE = Entry(window,
                bd=3,
                width=35)
searchE.place(x=30, y=80)

# Search_ListBox Create
LBscrollbar1 = Scrollbar(window)
searchLB = Listbox(window,
                   bd=8,
                   width=50,
                   height=25,
                   yscrollcommand=LBscrollbar1.set)
LBscrollbar1.place(x=390, y=160, height=420)
searchLB.place(x=20, y=160)
LBscrollbar1.config(command=searchLB.yview)

# Check_List Create
CheckVar = IntVar()
check1 = Radiobutton(window,
                     text="인기순",
                     value = 0,
                     variable=CheckVar)
check2 = Radiobutton(window,
                     text="최고가순",
                     value = 1,
                     variable=CheckVar)
check3 = Radiobutton(window,
                     text="최저가순",
                     value = 2,
                     variable=CheckVar)
check4 = Radiobutton(window,
                     text="리뷰순",
                     value = 3,
                     variable=CheckVar)
check1.place(x=30, y=130)
check2.place(x=110, y=130)
check3.place(x=200, y=130)
check4.place(x=290, y=130)

def test():
    s = searchLB.curselection()[0]
    t = searchLB.get(s)
    print(searchLB.curselection()," : ", t)

# Goto_Detail_Button Create
detailB = Button(window,
                 text="상세보기",
                 width=50,
                 height=4,
                 command=test)
detailB.place(x=420, y=500)

var = StringVar()
detailM = Message(window,
                  textvariable = var,
                  relief=SOLID,
                  anchor = 'nw')
var.set("show \nme the money")
detailM.place(x = 420, y = 160, width = 360, height = 320)
window.mainloop()
